from flask import render_template, redirect, url_for
from flask import Blueprint 

tarefas_bp = Blueprint("tarefas", __name__)

@tarefas_bp.route("/login")
def login():
    return render_template('login.html')
    