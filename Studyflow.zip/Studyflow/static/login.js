// ===== STUDYFLOW AUTH =====
// Usuários ficam salvos no localStorage

function switchTab(tab) {
  document.getElementById('form-login').classList.toggle('hidden', tab !== 'login');
  document.getElementById('form-register').classList.toggle('hidden', tab !== 'register');
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-register').classList.toggle('active', tab !== 'login');
  showMsg('', '');
}

function showMsg(text, tipo) {
  const el = document.getElementById('auth-msg');
  el.textContent = text;
  el.className = 'auth-msg' + (tipo ? ' ' + tipo : '');
}

function getUsers() {
  return JSON.parse(localStorage.getItem('sf_users') || '{}');
}

function saveUsers(users) {
  localStorage.setItem('sf_users', JSON.stringify(users));
}

// ---- LOGIN ----
function doLogin() {
  const user = document.getElementById('login-user').value.trim();
  const pass = document.getElementById('login-pass').value;

  if (!user || !pass) {
    showMsg('Preencha todos os campos.', 'erro');
    return;
  }

  const users = getUsers();

  if (!users[user]) {
    showMsg('Usuário não encontrado.', 'erro');
    return;
  }

  if (users[user].senha !== btoa(pass)) {
    showMsg('Senha incorreta.', 'erro');
    return;
  }

  // Salva sessão
  localStorage.setItem('sf_logged', user);
  showMsg('Entrando...', 'sucesso');

  setTimeout(() => {
    window.location.href = '/';  // redireciona para a home
  }, 700);
}

// ---- CADASTRO ----
function doRegister() {
  const user  = document.getElementById('reg-user').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass  = document.getElementById('reg-pass').value;
  const pass2 = document.getElementById('reg-pass2').value;

  if (!user || !email || !pass || !pass2) {
    showMsg('Preencha todos os campos.', 'erro');
    return;
  }

  if (user.length < 3) {
    showMsg('Usuário deve ter ao menos 3 caracteres.', 'erro');
    return;
  }

  if (pass.length < 6) {
    showMsg('Senha deve ter ao menos 6 caracteres.', 'erro');
    return;
  }

  if (pass !== pass2) {
    showMsg('As senhas não coincidem.', 'erro');
    return;
  }

  const users = getUsers();

  if (users[user]) {
    showMsg('Usuário já existe. Escolha outro nome.', 'erro');
    return;
  }

  users[user] = { email, senha: btoa(pass) };
  saveUsers(users);

  showMsg('Conta criada! Faça login.', 'sucesso');
  setTimeout(() => switchTab('login'), 1200);
}

// Enter nos inputs
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const loginVisible = !document.getElementById('form-login').classList.contains('hidden');
  if (loginVisible) doLogin();
  else doRegister();
});
